﻿using Microsoft.Data.SqlClient;

namespace Main_Project.Models
{
    public class StudentRepository
    {
        private string? connectionstring;

        public StudentRepository(IConfiguration configuration)
        {
            connectionstring = configuration.GetConnectionString("mycon");
        }
        
        public List<Student> GetAll()
        {
            var std =new List<Student>();
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("Select *from student", con);
            con.Open();
            SqlDataReader sdr=cmd.ExecuteReader();

            while (sdr.Read())
            {
                std.Add(new Student
                {
                    Id = (int)sdr["id"],
                    Name = sdr["Name"].ToString(),
                    Dept = sdr["dept"].ToString(),
                    Mark = (double)sdr["Mark"]
                });
            }
            return std;
        }

        public void Add(Student s)
        {
            SqlConnection con=new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("insert into student values(@Name, @Dept,@Mark)", con);
            cmd.Parameters.AddWithValue("@Name", s.Name);
            cmd.Parameters.AddWithValue("@Dept", s.Dept);
            cmd.Parameters.AddWithValue("@Mark", s.Mark);
            con.Open();
            cmd.ExecuteNonQuery();
        }

        public void Update(Student s)
        {
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("update student set mark=@Mark where id=@Id", con);
            cmd.Parameters.AddWithValue("@Id", s.Id);
            cmd.Parameters.AddWithValue("@Mark", s.Mark);
            con.Open();
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            SqlConnection con = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("delete from student where id=@Id", con);
            cmd.Parameters.AddWithValue("@Id", id);
            con.Open();
            cmd.ExecuteNonQuery();
        }
    }
}
