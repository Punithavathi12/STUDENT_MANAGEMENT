using System.Diagnostics;
using Main_Project.Models;
using Microsoft.AspNetCore.Mvc;

namespace Main_Project.Controllers
{
    public class HomeController : Controller
    {
        private StudentRepository repo;
        public HomeController(StudentRepository sr)
        {
            repo = sr;
        }

        public IActionResult Index()
        {
            var students = repo.GetAll();
            return View(students);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student st)
        {
            if (ModelState.IsValid)
            {
                repo.Add(st);
                return RedirectToAction("Index");
            }
            return View(st);
        }
        public IActionResult Update()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Update(Student st)
        {
            if (ModelState.IsValid)
            {
                repo.Update(st);
                return RedirectToAction("Index");
            }
            return View(st);
        }

        public IActionResult Delete(int id)
        {

            repo.Delete(id);
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
